global operationHistory;
global lastCalculation;

operationHistory = [];
lastCalculation = "";

//Info function-----------------------------------------------------------------
function info = matrixInfo(A)

    info = "Rows : " + string(size(A,1)) + ascii(10) + ...
           "Cols : " + string(size(A,2)) + ascii(10) + ...
           "Rank : " + string(rank(A));

endfunction


f=figure('figure_position',[785,3],'figure_size',[587,689],'auto_resize','on','background',[34],'figure_name','Graphic window number %d','color_map',[0,0,0;0,0,1;0,1,0;0,1,1;1,0,0;1,0,1;1,1,0;1,1,1;0,0,0.5647059;0,0,0.6901961;0,0,0.8156863;0.5294118,0.8078431,1;0,0.5647059,0;0,0.6901961,0;0,0.8156863,0;0,0.5647059,0.5647059;0,0.6901961,0.6901961;0,0.8156863,0.8156863;0.5647059,0,0;0.6901961,0,0;0.8156863,0,0;0.5647059,0,0.5647059;0.6901961,0,0.6901961;0.8156863,0,0.8156863;0.5019608,0.1882353,0;0.627451,0.2509804,0;0.7529412,0.3764706,0;1,0.5019608,0.5019608;1,0.627451,0.627451;1,0.7529412,0.7529412;1,0.8784314,0.8784314;1,0.8431373,0;0.8,0.8,0.8;0.9333333,0.9333333,0.9333333],'dockable','off','infobar_visible','off','toolbar_visible','off','menubar_visible','off','default_axes','on','visible','off');

handles.dummy = 0;

handles.heading=uicontrol(f,'unit','normalized','BackgroundColor',[0.94,0.94,0.94],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[32],'FontUnits','points','FontWeight','bold','ForegroundColor',[0.1 0.2 0.5],'HorizontalAlignment','center','ListboxTop',[],'Max',[20],'Min',[0],'Position',[0.15 0.90 0.70 0.07],'Relief','default','SliderStep',[0.01,0.1],'String','Matrix Solver Pro','Style','text','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','heading','Callback','')

handles.labelA=uicontrol(f,'unit','normalized','BackgroundColor',[245 247 250]/255,'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[18],'FontUnits','points','FontWeight','bold','ForegroundColor',[0.2 0.2 0.2],'HorizontalAlignment','center','ListboxTop',[],'Max',[20],'Min',[0],'Position',[0.08 0.83 0.20 0.04],'Relief','default','SliderStep',[0.01,0.1],'String','Matrix A','Style','text','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','labelA','Callback','')

handles.labelB=uicontrol(f,'unit','normalized','BackgroundColor',[245 247 250]/255,'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[18],'FontUnits','points','FontWeight','bold','ForegroundColor',[0.2 0.2 0.2],'HorizontalAlignment','center','ListboxTop',[],'Max',[20],'Min',[0],'Position',[0.70 0.83 0.20 0.04],'Relief','default','SliderStep',[0.01,0.1],'String','Matrix B','Style','text','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','labelB','Callback','')

handles.infoTitle=uicontrol(f,'unit','normalized','BackgroundColor',[0.94,0.94,0.94],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[14],'FontUnits','points','FontWeight','bold','ForegroundColor',[-1 -1 -1],'HorizontalAlignment','center','ListboxTop',[],'Max',[20],'Min',[0],'Position',[0.67 0.23 0.15 0.04],'Relief','default','SliderStep',[0.01,0.1],'String','Matrix Information','Style','text','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','infoTitle','Callback','')

handles.resultLabel=uicontrol(f,'unit','normalized','BackgroundColor',[0.94,0.94,0.94],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[18],'FontUnits','points','FontWeight','bold','ForegroundColor',[0.2 0.2 0.2],'HorizontalAlignment','center','ListboxTop',[],'Max',[20],'Min',[0],'Position',[0.25 0.23 0.15 0.04],'Relief','default','SliderStep',[0.01,0.1],'String','Result','Style','text','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','resultLabel','Callback','')


handles.editA=uicontrol(f,'unit','normalized','BackgroundColor',[-1,-1,-1],'Enable','on','FontAngle','normal','FontName','Consolas','FontSize',[17],'FontUnits','points','FontWeight','normal','ForegroundColor',[-1,-1,-1],'HorizontalAlignment','left','ListboxTop',[],'Max',[20],'Min',[0],'Position', [0.06 0.58 0.38 0.22],'Relief','default','SliderStep',[0.01,0.1],'String','Enter Matrix A','Style','edit','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','editA','Callback','')

handles.editB=uicontrol(f,'unit','normalized','BackgroundColor',[-1,-1,-1],'Enable','on','FontAngle','normal','FontName','Consolas','FontSize',[17],'FontUnits','points','FontWeight','normal','ForegroundColor',[-1,-1,-1],'HorizontalAlignment','left','ListboxTop',[],'Max',[20],'Min',[0],'Position', [0.55 0.58 0.38 0.22],'Relief','default','SliderStep',[0.01,0.1],'String','Enter Matrix B (Optional)','Style','edit','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','editB','Callback','')



handles.editResult=uicontrol(f,'unit','normalized','BackgroundColor',[0.98 0.98 1],'Enable','on','FontAngle','normal','FontName','Consolas','FontSize',[17],'FontUnits','points','FontWeight','normal','ForegroundColor',[-1,-1,-1],'HorizontalAlignment','left','ListboxTop',[],'Max',[20],'Min',[0],'Position',[0.07 0.02 0.47 0.20],'Relief','default','SliderStep',[0.01,0.1],'String','Result Here !','Style','edit','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','editResult','Callback','')

handles.editInfo=uicontrol(f,'unit','normalized','BackgroundColor',[-1,-1,-1],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[17],'FontUnits','points','FontWeight','normal','ForegroundColor',[-1,-1,-1],'HorizontalAlignment','left','ListboxTop',[],'Max',[20],'Min',[0],'Position',[0.60 0.02 0.30 0.20],'Relief','default','SliderStep',[0.01,0.1],'String','Rows : --'+ascii(10)+'Cols : --'+ascii(10)+'Rank : --','Style','edit','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','editInfo','Callback','matrixInfo()')

handles.add=uicontrol(f,'unit','normalized','BackgroundColor',[[0.20 0.45 0.80]],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[12],'FontUnits','points','FontWeight','normal','ForegroundColor',[1,1,1],'HorizontalAlignment','center','ListboxTop',[],'Max',[1],'Min',[0],'Position',[0.09 0.50 0.14 0.05],'Relief','default','SliderStep',[0.01,0.1],'String','Add','Style','pushbutton','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','add','Callback','add_callback(handles)')

handles.sub=uicontrol(f,'unit','normalized','BackgroundColor',[0.20,0.45,0.80],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[12],'FontUnits','points','FontWeight','normal','ForegroundColor',[1,1,1],'HorizontalAlignment','center','ListboxTop',[],'Max',[1],'Min',[0],'Position',[0.24 0.50 0.14 0.05],'Relief','default','SliderStep',[0.01,0.1],'String','Subtract','Style','pushbutton','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','sub','Callback','sub_callback(handles)')

handles.trans=uicontrol(f,'unit','normalized','BackgroundColor',[0.20 0.45 0.80],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[12],'FontUnits','points','FontWeight','normal','ForegroundColor',[1,1,1],'HorizontalAlignment','center','ListboxTop',[],'Max',[1],'Min',[0],'Position', [0.57 0.50 0.14 0.05],'Relief','default','SliderStep',[0.01,0.1],'String','Transpose','Style','pushbutton','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','trans','Callback','trans_callback(handles)')

handles.deter=uicontrol(f,'unit','normalized','BackgroundColor',[0.20 0.45 0.80],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[12],'FontUnits','points','FontWeight','normal','ForegroundColor',[1,1,1],'HorizontalAlignment','center','ListboxTop',[],'Max',[1],'Min',[0],'Position',[0.09 0.43 0.14 0.05],'Relief','default','SliderStep',[0.01,0.1],'String','Determinant','Style','pushbutton','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','deter','Callback','deter_callback(handles)')

handles.inverse=uicontrol(f,'unit','normalized','BackgroundColor',[0.20 0.45 0.80],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[12],'FontUnits','points','FontWeight','normal','ForegroundColor',[1,1,1],'HorizontalAlignment','center','ListboxTop',[],'Max',[1],'Min',[0],'Position',[0.73 0.50 0.14 0.05],'Relief','default','SliderStep',[0.01,0.1],'String','Inverse','Style','pushbutton','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','inverse','Callback','inverse_callback(handles)')

handles.rank=uicontrol(f,'unit','normalized','BackgroundColor',[0.20 0.45 0.80],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[12],'FontUnits','points','FontWeight','normal','ForegroundColor',[1,1,1],'HorizontalAlignment','center','ListboxTop',[],'Max',[1],'Min',[0],'Position',[0.25 0.43 0.14 0.05],'Relief','default','SliderStep',[0.01,0.1],'String','Rank','Style','pushbutton','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','rank','Callback','rank_callback(handles)')

handles.solve=uicontrol(f,'unit','normalized','BackgroundColor',[0.20 0.45 0.80],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[12],'FontUnits','points','FontWeight','normal','ForegroundColor',[1,1,1],'HorizontalAlignment','center','ListboxTop',[],'Max',[1],'Min',[0],'Position',[0.57 0.43 0.14 0.05],'Relief','default','SliderStep',[0.01,0.1],'String','Solve AX=B','Style','pushbutton','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','solve','Callback','solve_callback(handles)')

handles.eigen=uicontrol(f,'unit','normalized','BackgroundColor',[0.20 0.45 0.80],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[12],'FontUnits','points','FontWeight','normal','ForegroundColor',[1,1,1],'HorizontalAlignment','center','ListboxTop',[],'Max',[1],'Min',[0],'Position',[0.41 0.43 0.14 0.05],'Relief','default','SliderStep',[0.01,0.1],'String','Eigen','Style','pushbutton','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','eigen','Callback','eigen_callback(handles)')

handles.random=uicontrol(f,'unit','normalized','BackgroundColor',[0.20 0.45 0.80],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[12],'FontUnits','points','FontWeight','normal','ForegroundColor',[1,1,1],'HorizontalAlignment','center','ListboxTop',[],'Max',[1],'Min',[0],'Position', [0.73 0.43 0.14 0.05],'Relief','default','SliderStep',[0.01,0.1],'String','Random','Style','pushbutton','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','random','Callback','random_callback(handles)')

handles.save_result=uicontrol(f,'unit','normalized','BackgroundColor',[0.20 0.65 0.30],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[12],'FontUnits','points','FontWeight','normal','ForegroundColor',[-1,-1,-1],'HorizontalAlignment','center','ListboxTop',[],'Max',[1],'Min',[0],'Position',[0.25 0.29 0.14 0.05],'Relief','default','SliderStep',[0.01,0.1],'String','Save Result','Style','pushbutton','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','save_result','Callback','save_result_callback(handles)')

handles.clear=uicontrol(f,'unit','normalized','BackgroundColor',[0.85 0.25 0.25],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[12],'FontUnits','points','FontWeight','normal','ForegroundColor',[-1,-1,-1],'HorizontalAlignment','center','ListboxTop',[],'Max',[1],'Min',[0],'Position',[0.73 0.29 0.14 0.05],'Relief','default','SliderStep',[0.01,0.1],'String','Clear','Style','pushbutton','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','clear','Callback','clear_callback(handles)')

handles.multi=uicontrol(f,'unit','normalized','BackgroundColor',[0.20 0.45 0.80],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[12],'FontUnits','points','FontWeight','normal','ForegroundColor',[1,1,1],'HorizontalAlignment','center','ListboxTop',[],'Max',[1],'Min',[0],'Position',[0.41 0.50 0.14 0.05],'Relief','default','SliderStep',[0.01,0.1],'String','Multiply','Style','pushbutton','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','multi','Callback','multi_callback(handles)')

handles.btnType=uicontrol(f,'unit','normalized','BackgroundColor',[0.20 0.45 0.80],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[12],'FontUnits','points','FontWeight','normal','ForegroundColor',[-1,-1,-1],'HorizontalAlignment','center','ListboxTop',[],'Max',[50],'Min',[0],'Position',[0.09 0.29 0.14 0.05],'Relief','default','SliderStep',[0.01,0.1],'String','Matrix Type','Style','pushbutton','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','btntype','Callback','matrixType_callback(handles)')

handles.btnLU=uicontrol(f,'unit','normalized','BackgroundColor',[-1,-1,-1],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[12],'FontUnits','points','FontWeight','normal','ForegroundColor',[-1,-1,-1],'HorizontalAlignment','center','ListboxTop',[],'Max',[50],'Min',[0],'Position',[0.09 0.36 0.14 0.05],'Relief','default','SliderStep',[0.01,0.1],'String','LU','Style','pushbutton','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','btnlu','Callback','LU_callback(handles)')

handles.btnQR=uicontrol(f,'unit','normalized','BackgroundColor',[-1,-1,-1],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[12],'FontUnits','points','FontWeight','normal','ForegroundColor',[-1,-1,-1],'HorizontalAlignment','center','ListboxTop',[],'Max',[50],'Min',[0],'Position',[0.25 0.36 0.14 0.05],'Relief','default','SliderStep',[0.01,0.1],'String','QR','Style','pushbutton','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','btnqr','Callback','QR_callback(handles)')

handles.btnSVD=uicontrol(f,'unit','normalized','BackgroundColor',[-1,-1,-1],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[12],'FontUnits','points','FontWeight','normal','ForegroundColor',[-1,-1,-1],'HorizontalAlignment','center','ListboxTop',[],'Max',[50],'Min',[0],'Position',[0.41 0.36 0.14 0.05],'Relief','default','SliderStep',[0.01,0.1],'String','SVD','Style','pushbutton','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','btnsvd','Callback','SVD_callback(handles)')

handles.btnNorm=uicontrol(f,'unit','normalized','BackgroundColor',[-1,-1,-1],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[12],'FontUnits','points','FontWeight','normal','ForegroundColor',[-1,-1,-1],'HorizontalAlignment','center','ListboxTop',[],'Max',[50],'Min',[0],'Position',[0.73 0.36 0.14 0.05],'Relief','default','SliderStep',[0.01,0.1],'String','Norm','Style','pushbutton','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','btnorm','Callback','Norm_callback(handles)')

handles.btnCond=uicontrol(f,'unit','normalized','BackgroundColor',[-1,-1,-1],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[12],'FontUnits','points','FontWeight','normal','ForegroundColor',[-1,-1,-1],'HorizontalAlignment','center','ListboxTop',[],'Max',[50],'Min',[0],'Position',[0.57 0.36 0.14 0.05],'Relief','default','SliderStep',[0.01,0.1],'String','Condition','Style','pushbutton','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','btncond','Callback','Cond_callback(handles)')

handles.histbtn=uicontrol(f,'unit','normalized','BackgroundColor',[0.12 0.40 0.70],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[12],'FontUnits','points','FontWeight','normal','ForegroundColor',[-1 -1 -1],'HorizontalAlignment','center','ListboxTop',[],'Max',[50],'Min',[0],'Position',[0.41 0.29 0.14 0.05],'Relief','default','SliderStep',[0.01,0.1],'String','Add to History','Style','pushbutton','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','btncond','Callback','add_to_history_btn_callback()')

handles.histbtn1=uicontrol(f,'unit','normalized','BackgroundColor',[0.18 0.55 0.34],'Enable','on','FontAngle','normal','FontName','Tahoma','FontSize',[12],'FontUnits','points','FontWeight','normal','ForegroundColor',[-1 -1 -1],'HorizontalAlignment','center','ListboxTop',[],'Max',[50],'Min',[0],'Position',[0.57 0.29 0.14 0.05],'Relief','default','SliderStep',[0.01,0.1],'String','Display History','Style','pushbutton','Value',[0],'VerticalAlignment','middle','Visible','on','Tag','btncond','Callback','display_history_btn_callback()')

f.background = color("white");
f.visible='on'

//All Functions----------------------------------------------------------------------------------
//Addition
function add_callback(handles)

    global lastCalculation;

    try

        inputA = get(handles.editA, "string");
        inputB = get(handles.editB, "string");

        if inputA == "" then
            set(handles.editResult, "string", "Please enter Matrix A.");
            return;
        end

        if inputB == "" then
            set(handles.editResult, "string", "Please enter Matrix B.");
            return;
        end

        A = evstr(inputA);
        B = evstr(inputB);

        // Check dimensions
        if size(A,1) <> size(B,1) | size(A,2) <> size(B,2) then
            set(handles.editResult, ...
                "string", ...
                "Matrices must have the same dimensions.");
            return;
        end

        // Addition
        R = A + B;

        // Round to 2 decimals
        R = round(R * 100) / 100;

        // Convert to string
        strR = sci2exp(R);

        // Result message
        msg = "Matrix Addition" + ascii(10);
        msg = msg + "--------------------" + ascii(10);
        msg = msg + "A + B =" + ascii(10);
        msg = msg + strR;

        set(handles.editResult, "string", msg);

        // Save latest calculation
        lastCalculation = ...
            "ADD(" + inputA + ", " + inputB + ") -> " + msg;


        handles.editInfo.string = matrixInfo(A);
    catch

        set(handles.editResult, ...
            "string", ...
            "Invalid Matrix Input");

    end

endfunction

//Substraction------------------------------------------------------------------------
function sub_callback(handles)

    global lastCalculation;

    try

        inputA = get(handles.editA, "string");
        inputB = get(handles.editB, "string");

        if inputA == "" then
            set(handles.editResult, "string", "Please enter Matrix A.");
            return;
        end

        if inputB == "" then
            set(handles.editResult, "string", "Please enter Matrix B.");
            return;
        end

        A = evstr(inputA);
        B = evstr(inputB);

        // Check dimensions
        if size(A,1) <> size(B,1) | size(A,2) <> size(B,2) then
            set(handles.editResult, ...
                "string", ...
                "Matrices must have the same dimensions.");
            return;
        end

        // Subtraction
        R = A - B;

        // Round
        R = round(R * 100) / 100;

        // Convert to string
        strR = sci2exp(R);

        // Result message
        msg = "Matrix Subtraction" + ascii(10);
        msg = msg + "--------------------" + ascii(10);
        msg = msg + "A - B =" + ascii(10);
        msg = msg + strR;

        set(handles.editResult, "string", msg);

        // Save latest calculation
        lastCalculation = ...
            "SUBTRACT(" + inputA + ", " + inputB + ") -> " + msg;


        handles.editInfo.string = matrixInfo(A);
    catch

        set(handles.editResult, ...
            "string", ...
            "Subtraction Error");

    end

endfunction

//Transpose-------------------------------------------------------
function trans_callback(handles)

    global lastCalculation;

    try

        inputStr = get(handles.editA, "string");

        if inputStr == "" then
            set(handles.editResult, ...
                "string", ...
                "Please enter Matrix A.");
            return;
        end

        A = evstr(inputStr);

        // Transpose
        R = A';

        // Round
        R = round(R * 100) / 100;

        // Convert to string
        strR = sci2exp(R);

        // Result
        msg = "Matrix Transpose" + ascii(10);
        msg = msg + "--------------------" + ascii(10);
        msg = msg + "A" + ascii(10);
        msg = msg + strR;

        set(handles.editResult, "string", msg);


        handles.editInfo.string = matrixInfo(R);
        
        // Save latest calculation
        lastCalculation = ...
            "TRANSPOSE(" + inputStr + ") -> " + msg;

    catch

        set(handles.editResult, ...
            "string", ...
            "Transpose Error");

    end

endfunction

//Determinant----------------------------------------------------------------------
function deter_callback(handles)

    global lastCalculation;

    try

        inputStr = get(handles.editA, "string");

        if inputStr == "" then
            set(handles.editResult, ...
                "string", ...
                "Please enter Matrix A.");
            return;
        end

        A = evstr(inputStr);

        // Check square matrix first
        if size(A,1) <> size(A,2) then
            set(handles.editResult, ...
                "string", ...
                "Square Matrix Required");
            return;
        end

        // Calculate determinant
        d = det(A);

        // Remove tiny floating-point values
        if abs(d) < 1D-10 then
            d = 0;
        end

        // Round
        d = round(d * 100) / 100;

        msg = "Determinant = " + string(d);

        set(handles.editResult, ...
            "string", ...
            msg);
    
        // Save latest calculation
        lastCalculation = ...
            "DET(" + inputStr + ") -> " + msg;


        handles.editInfo.string = matrixInfo(A);
    catch

        set(handles.editResult, ...
            "string", ...
            "Determinant Error");

    end

endfunction

//Inverse------------------------------------------------------------------
function inverse_callback(handles)

    global lastCalculation;

    try

        inputStr = get(handles.editA, "string");

        if inputStr == "" then
            set(handles.editResult, ...
                "string", ...
                "Please enter Matrix A.");
            return;
        end

        A = evstr(inputStr);

        // Check square matrix
        if size(A,1) <> size(A,2) then
            set(handles.editResult, ...
                "string", ...
                "Square Matrix Required");
            return;
        end

        // Check determinant
        d = det(A);

        if abs(d) < 1D-10 then

            set(handles.editResult, ...
                "string", ...
                "Matrix is singular. Inverse does not exist.");

            return;

        end

        // Calculate inverse
        R = inv(A);

        // Round to 2 decimal places
        R = round(R * 100) / 100;

        // Remove tiny values
        for i = 1:size(R,1)
            for j = 1:size(R,2)

                if abs(R(i,j)) < 1D-10 then
                    R(i,j) = 0;
                end

            end
        end

        // Convert to string
        strR = sci2exp(R);

        msg = "Matrix Inverse" + ascii(10);
        msg = msg + "--------------------" + ascii(10);
        msg = msg + "A⁻¹ =" + ascii(10);
        msg = msg + strR;

        set(handles.editResult, ...
            "string", ...
            msg);


        handles.editInfo.string = matrixInfo(A);
        
        // Save latest calculation
        lastCalculation = ...
            "INVERSE(" + inputStr + ") -> " + msg;

    catch

        set(handles.editResult, ...
            "string", ...
            "Inverse Not Possible");

    end

endfunction

//Rank of matrix-----------------------------------------------------------------
function rank_callback(handles)

    global lastCalculation;

    try

        inputStr = get(handles.editA, "string");

        if inputStr == "" then
            set(handles.editResult, ...
                "string", ...
                "Please enter Matrix A.");
            return;
        end

        A = evstr(inputStr);

        r = rank(A);

        msg = "Rank = " + string(r);

        set(handles.editResult, ...
            "string", ...
            msg);

        // Save latest calculation
        lastCalculation = ...
            "RANK(" + inputStr + ") -> " + msg;


        handles.editInfo.string = matrixInfo(A);
        
    catch

        set(handles.editResult, ...
            "string", ...
            "Rank Error");

    end

endfunction

//Solving AX=B-----------------------------------------------------------
function solve_callback(handles)

    global lastCalculation;

    try

        inputA = get(handles.editA, "string");
        inputB = get(handles.editB, "string");

        if inputA == "" then
            set(handles.editResult, ...
                "string", ...
                "Please enter Matrix A.");
            return;
        end

        if inputB == "" then
            set(handles.editResult, ...
                "string", ...
                "Please enter Matrix B.");
            return;
        end

        A = evstr(inputA);
        B = evstr(inputB);

        // A must be square
        if size(A,1) <> size(A,2) then

            set(handles.editResult, ...
                "string", ...
                "Matrix A must be square.");

            return;

        end

        // Rows of A and B must match
        if size(A,1) <> size(B,1) then

            set(handles.editResult, ...
                "string", ...
                "Rows of A and B must match.");

            return;

        end

        // Check singularity
        d = det(A);

        if abs(d) < 1D-10 then

            set(handles.editResult, ...
                "string", ...
                "Matrix A is singular. Unique solution does not exist.");

            return;

        end

        // Solve AX = B
        R = A \ B;

        // Round to 2 decimals
        R = round(R * 100) / 100;

        // Remove tiny values
        for i = 1:size(R,1)
            for j = 1:size(R,2)

                if abs(R(i,j)) < 1D-10 then
                    R(i,j) = 0;
                end

            end
        end


        strR = sci2exp(R);

        msg = "Linear System Solution" + ascii(10);
        msg = msg + "--------------------" + ascii(10);
        msg = msg + "X =" + ascii(10);
        msg = msg + strR;

        set(handles.editResult, ...
            "string", ...
            msg);

        // Save latest calculation
        lastCalculation = ...
            "SOLVE(" + inputA + ", " + inputB + ") -> " + msg;


        handles.editInfo.string = matrixInfo(A);
        
    catch

        set(handles.editResult, ...
            "string", ...
            "Cannot Solve System");

    end

endfunction

//Eigen Values------------------------------------------------------------------
function eigen_callback(handles)

    global lastCalculation;

    try

        inputStr = get(handles.editA, "string");

        if inputStr == "" then
            set(handles.editResult, ...
                "string", ...
                "Please enter Matrix A.");
            return;
        end

        A = evstr(inputStr);

        // Eigenvalues
        lambda = spec(A);

        // Round
        lambda = round(lambda * 1000) / 1000;

        // Remove tiny values
        for i = 1:length(lambda)

            if abs(lambda(i)) < 1D-10 then
                lambda(i) = 0;
            end

        end

        // Convert to string
        strLambda = sci2exp(lambda);

        msg = "Eigenvalues" + ascii(10);
        msg = msg + "--------------------" + ascii(10);
        msg = msg + strLambda;

        set(handles.editResult, ...
            "string", ...
            msg);

        // Save latest calculation
        lastCalculation = ...
            "EIGENVALUES(" + inputStr + ") -> " + msg;


        handles.editInfo.string = matrixInfo(A);            

    catch

        set(handles.editResult, ...
            "string", ...
            "Eigen Computation Error");

    end

endfunction

//Random Matrix--------------------------------------------------------------
function random_callback(handles)

    global lastCalculation;

    try

        // Generate 3x3 random integer matrix
        R = grand(3, 3, "uin", 1, 9);

        // Convert to string
        strR = sci2exp(R);

        // Result message
        msg = "Random 3 × 3 Matrix" + ascii(10);
        msg = msg + "--------------------" + ascii(10);
        msg = msg + strR;

        // Display result
        set(handles.editResult, ...
            "string", ...
            msg);

        // Save latest calculation
        lastCalculation = ...
            "RANDOM MATRIX -> " + msg;


        handles.editInfo.string = matrixInfo(R);
    catch

        set(handles.editResult, ...
            "string", ...
            "Unable to generate random matrix");

    end

endfunction

//Save--------------------------------------------------------------------------
function save_result_callback(handles)

    try

        // Get current result
        resultText = get(handles.editResult, "string");

        // Check whether there is something to save
        if size(resultText, "*") == 0 then

            messagebox("There is no result to save.", ...
                       "Save Result", ...
                       "warning");

            return;

        end


        // Ask user for filename
        filename = uiputfile("result.txt");


        // Check whether user cancelled
        if filename <> "" then

            // Save result to file
            mputl(resultText, filename);

            // Confirmation
            messagebox("Result saved successfully.", ...
                       "Save Result", ...
                       "info");

        end


    catch

        messagebox("Unable to save the result.", ...
                   "Save Result", ...
                   "error");

    end

endfunction

//Clear----------------------------------------------------------------------

function clear_callback(handles)

    // Clear Matrix A
    set(handles.editA, "string", "");


    // Clear Matrix B
    set(handles.editB, "string", "");


    // Clear Result
    set(handles.editResult, "string", "");


    // Clear Information/Status area
    set(handles.editInfo, "string", "");

endfunction

//Mulitiplication------------------------------------------------------------------
function multi_callback(handles)

    global lastCalculation;

    try
        inputA = get(handles.editA, "string");
        inputB = get(handles.editB, "string");

        // Check empty input
        if inputA == "" then

            set(handles.editResult, ...
                "string", ...
                "Please enter matrix A.");

            return;

        end

        if inputB == "" then

            set(handles.editResult, ...
                "string", ...
                "Please enter matrix B.");

            return;

        end

        A = evstr(inputA);
        B = evstr(inputB);

        if size(A, 2) <> size(B, 1) then

            set(handles.editResult, ...
                "string", ...
                "Matrix dimensions are not compatible.");

            return;

        end
        R = A * B;

        R_rounded = round(R * 100) / 100;

        strR = sci2exp(R_rounded);

        msg = "Matrix Multiplication" + ascii(10);
        msg = msg + "--------------------" + ascii(10);
        msg = msg + "A × B =" + ascii(10);
        msg = msg + strR;

        set(handles.editResult, ...
            "string", ...
            msg);

        lastCalculation = ...
            "MULTIPLY(" + inputA + ", " + inputB + ") -> " + msg;

        handles.editInfo.string = matrixInfo(R);

    catch

        set(handles.editResult, ...
            "string", ...
            "Matrix multiplication error.");

    end

endfunction

//Matrix type-------------------------------------------------------
function matrixType_callback(handles)

    global lastCalculation;

    try

        inputStr = get(handles.editA, "string");

        if inputStr == "" then

            set(handles.editResult, ...
                "string", ...
                "Please enter a matrix in A.");

            return;

        end

        A = evstr(inputStr);

        if size(A, 1) <> size(A, 2) then

            msg = "Not Square Matrix";

        elseif det(A) == 0 then

            msg = "Singular Matrix";

        elseif A == A' then

            msg = "Symmetric Matrix";

        else

            msg = "General Matrix";

        end

        set(handles.editResult, ...
            "string", ...
            msg);
            
        handles.editInfo.string = matrixInfo(A);

        lastCalculation = ...
            "MATRIX TYPE(" + inputStr + ") -> " + msg;

    catch

        set(handles.editResult, ...
            "string", ...
            "Unable to determine matrix type.");

    end

endfunction

//LU----------------------------------------------------------------
function LU_callback(handles)

    global lastCalculation;

    try

        inputStr = get(handles.editA, "string");

        // Check empty input
        if inputStr == "" then

            set(handles.editResult, ...
                "string", ...
                "Please enter a matrix in A.");

            return;

        end

        A = evstr(inputStr);

        [L, U] = lu(A);

        L_rounded = round(L * 100) / 100;
        U_rounded = round(U * 100) / 100;

        strL = sci2exp(L_rounded);
        strU = sci2exp(U_rounded);

        msg = "LU Decomposition" + ascii(10);
        msg = msg + "--------------------" + ascii(10);
        msg = msg + "L Matrix:" + ascii(10);
        msg = msg + strL + ascii(10);
        msg = msg + ascii(10);
        msg = msg + "U Matrix:" + ascii(10);
        msg = msg + strU;

        set(handles.editResult, ...
            "string", ...
            msg);

        lastCalculation = ...
            "LU(" + inputStr + ") -> " + msg;
            

        handles.editInfo.string = matrixInfo(A);
                    
    catch
        set(handles.editResult, ...
            "string", ...
            "Invalid Matrix Input");

    end

endfunction
//QR----------------------------------------------------------------------------
function QR_callback(handles)

    global lastCalculation;

    try
        inputStr = get(handles.editA, "string");

        // Check empty input
        if inputStr == "" then

            set(handles.editResult, ...
                "string", ...
                "Please enter a matrix in A.");

            return;

        end
        A = evstr(inputStr);

        [Q, R] = qr(A);

        Q_rounded = round(Q * 100) / 100;
        R_rounded = round(R * 100) / 100;

        strQ = sci2exp(Q_rounded);
        strR = sci2exp(R_rounded);

        msg = "QR Decomposition" + ascii(10);
        msg = msg + "--------------------" + ascii(10);
        msg = msg + "Q Matrix:" + ascii(10);
        msg = msg + strQ + ascii(10);
        msg = msg + ascii(10);
        msg = msg + "R Matrix:" + ascii(10);
        msg = msg + strR;

        set(handles.editResult, ...
            "string", ...
            msg);

        lastCalculation = ...
            "QR(" + inputStr + ") -> " + msg;

        handles.editInfo.string = matrixInfo(A);
        
    catch
        set(handles.editResult, ...
            "string", ...
            "Invalid Matrix Input");

    end

endfunction

//SVD------------------------------------------------------------------
function SVD_callback(handles)

    global lastCalculation;

    try
        strA = get(handles.editA, "string");

        // Check empty input
        if strA == "" then

            set(handles.editResult, ...
                "string", ...
                "Please enter a matrix in A.");

            return;

        end

        if size(strA, "*") > 1 then
            strA = strcat(strA, ";");
        end

        A = evstr(strA);

        [U, S, V] = svd(A);

        s = diag(S);

        s = round(s * 100) / 100;

        msg = "SVD Analysis" + ascii(10);
        msg = msg + "--------------------" + ascii(10);
        msg = msg + "Singular Values:" + ascii(10);

        for i = 1:length(s)

            msg = msg + string(s(i)) + ascii(10);

        end
        set(handles.editResult, ...
            "string", ...
            msg);

        lastCalculation = ...
            "SVD(" + strA + ") -> " + msg;


        handles.editInfo.string = matrixInfo(A);
        
    catch
        set(handles.editResult, ...
            "string", ...
            "Invalid Matrix Input");

    end

endfunction

//Cond--------------------------------------------------------------------
function Cond_callback(handles)

    global lastCalculation;

    // Get input
    inputStr = get(handles.editA, "string");

    // Check empty input
    if inputStr == "" then

        set(handles.editResult, ...
            "string", ...
            "Please enter a matrix in A.");

        return;

    end

    // Convert text to matrix
    A = evstr(inputStr);

    // Calculate norm
    n = cond(A);

    // Round to 2 decimal places
    n_rounded = round(n * 100) / 100;

    // Create display message
    displayMsg = "Matrix Norm = " + string(n_rounded);

    // Show result
    set(handles.editResult, ...
        "string", ...
        displayMsg);

    // Save latest calculation
    lastCalculation = ...
        "COND(" + inputStr + ") -> " + displayMsg;
        
        handles.editInfo.string = matrixInfo(A);
        
endfunction

//Norm--------------------------------------------------------------------
function Norm_callback(handles)

    global lastCalculation;

    // Get input
    inputStr = get(handles.editA, "string");

    // Check empty input
    if inputStr == "" then

        set(handles.editResult, ...
            "string", ...
            "Please enter a matrix in A.");

        return;

    end

    // Convert text to matrix
    A = evstr(inputStr);

    // Calculate norm
    n = norm(A);

    // Round to 2 decimal places
    n_rounded = round(n * 100) / 100;

    // Create display message
    displayMsg = "Matrix Norm = " + string(n_rounded);

    // Show result
    set(handles.editResult, ...
        "string", ...
        displayMsg);

    // Save latest calculation
    lastCalculation = ...
        "NORM(" + inputStr + ") -> " + displayMsg;
        
        handles.editInfo.string = matrixInfo(A);
        
endfunction

//Log operation-------------------------------------------------------------------
function logOperation(opName, inputStr, rawResult)

    global operationHistory;

    // Format result
    if type(rawResult) == 1 then

        roundedResult = round(rawResult * 100) / 100;
        resultStr = sci2exp(roundedResult);

    else

        resultStr = string(rawResult);

    end

    // Create history entry
    entry = opName + "(" + inputStr + ") -> " + resultStr;

    // Add entry to history
    if size(operationHistory, "*") == 0 then
        operationHistory = [entry];
    else
        operationHistory = [operationHistory; entry];
    end

endfunction

//Adding to history button-------------------------------------------------------
function add_to_history_btn_callback(handles)

    global operationHistory;
    global lastCalculation;

    if lastCalculation == "" then

        set(handles.editResult, ...
            "string", ...
            "Nothing to add! Perform a calculation first.");

        return;

    end

    if size(operationHistory, "*") == 0 then

        operationHistory = [lastCalculation];

    else

        operationHistory = [operationHistory; lastCalculation];

    end

    set(handles.editResult, ...
        "string", ...
        "Saved to history successfully!");

    lastCalculation = "";

endfunction

//Displaing hostory button-------------------------------------------------------------
function display_history_btn_callback(handles)

    global operationHistory;

    // Check history
    if size(operationHistory, "*") == 0 then

        set(handles.editResult, ...
            "string", ...
            "No History Available");

        return;

    end

    // Display history vertically
    set(handles.editResult, ...
        "string", ...
        operationHistory);

endfunction
